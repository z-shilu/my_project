-- 创建数据库
CREATE DATABASE IF NOT EXISTS health_db;

-- 选择数据库
USE health_db;

-- 创建 User 表
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(50) NOT NULL
);

-- 创建 HealthReport 表
CREATE TABLE IF NOT EXISTS health_reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    blood_pressure VARCHAR(50),
    blood_sugar VARCHAR(50),
    lipid VARCHAR(50),
    ecg VARCHAR(50),
    conclusion TEXT
);

-- 创建 MedicalHistory 表
CREATE TABLE IF NOT EXISTS medical_histories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    past_medical_history TEXT,
    chronic_diseases TEXT,
    current_medications TEXT
);

-- 创建 HealthMonitoring 表
CREATE TABLE IF NOT EXISTS health_monitorings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    date VARCHAR(50),
    weight FLOAT,
    blood_pressure VARCHAR(50),
    blood_sugar FLOAT,
    steps INT,
    sleep_duration FLOAT
);

-- 插入默认用户数据
INSERT INTO users (username, password) 
SELECT 'admin', '12345'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE username = 'admin');

-- 你可以根据需要在这里插入一些默认的健康数据

