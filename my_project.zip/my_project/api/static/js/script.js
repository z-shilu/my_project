document.addEventListener('DOMContentLoaded', function () {
    // 获取所有导航链接
    const navLinks = document.querySelectorAll('.nav-link');
    // 获取所有模块内容
    const modules = document.querySelectorAll('.module-content');

    // 点击导航链接时，展示相应模块内容
    navLinks.forEach(link => {
        link.addEventListener('click', function (event) {
            event.preventDefault();  // 阻止默认链接跳转行为

            // 隐藏所有模块
            modules.forEach(module => {
                module.style.display = 'none';
            });

            // 获取目标模块ID
            const targetModule = document.getElementById(link.getAttribute('data-target'));

            // 显示点击的目标模块
            if (targetModule) {
                targetModule.style.display = 'block';
            }
        });
    });

    // 默认显示第一个模块（可选）
    if (modules.length > 0) {
        modules[0].style.display = 'block';
    }

    // 跳转到体检报告页面
    function showReport() {
        window.location.href = "/health-report";  // 使用 Flask 路由路径
    }

    // 跳转到病史记录页面
    function showMedicalHistory() {
        window.location.href = "/medical-history";  // 使用 Flask 路由路径
    }

    // 跳转到日常健康监测数据页面
    function showHealthData() {
        window.location.href = "/health-monitoring";  // 使用 Flask 路由路径
    }

    // 为按钮添加点击事件监听器
    document.getElementById('view-report-btn').addEventListener('click', showReport);
    document.getElementById('view-medical-history-btn').addEventListener('click', showMedicalHistory);
    document.getElementById('view-health-data-btn').addEventListener('click', showHealthData);
});
