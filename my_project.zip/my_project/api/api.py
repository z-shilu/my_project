#api.py
from flask import Flask, render_template, request, redirect, url_for, session
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# 配置数据库连接
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:root@db/health_db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# 用户模型
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(50), nullable=False)


# 健康报告模型
class HealthReport(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    blood_pressure = db.Column(db.String(50))
    blood_sugar = db.Column(db.String(50))
    lipid = db.Column(db.String(50))
    ecg = db.Column(db.String(50))
    conclusion = db.Column(db.Text)

# 病史记录模型
class MedicalHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    past_medical_history = db.Column(db.Text)
    chronic_diseases = db.Column(db.Text)
    current_medications = db.Column(db.Text)

# 日常健康监测数据模型
class HealthMonitoring(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.String(50))
    weight = db.Column(db.Float)
    blood_pressure = db.Column(db.String(50))
    blood_sugar = db.Column(db.Float)
    steps = db.Column(db.Integer)
    sleep_duration = db.Column(db.Float)

# 创建默认用户
def create_default_user():
    with app.app_context():
        user = User.query.first()
        if not user:
            new_user = User(username='admin', password='12345')
            db.session.add(new_user)
            db.session.commit()
            print("默认用户已创建")
        else:
            print("用户已存在")

# 登录页面视图
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        with app.app_context():
            user = User.query.filter_by(username=username).first()
            if user and user.password == password:
                session['logged_in'] = True
                return redirect(url_for('home'))
            else:
                # 如果用户名或密码错误，传递错误信息到前端
                return render_template('login.html', error="用户名或密码错误")
    return render_template('login.html')

# 登出功能
@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    return redirect(url_for('login'))


# 注册页面视图
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        confirm_password = request.form['confirm-password']

        # 判断两次密码是否一致
        if password != confirm_password:
            return render_template('register.html', error="密码不一致，请重新输入。")

        # 判断用户名是否已经存在
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            return render_template('register.html', error="该用户名已被注册。")

        # 创建新用户
        new_user = User(username=username, password=password)
        db.session.add(new_user)
        db.session.commit()
        return redirect(url_for('login'))

    return render_template('register.html')

# 主页视图
@app.route('/home')
def home():
    if 'logged_in' in session:
        return render_template('index.html')
    else:
        return redirect(url_for('login'))

# 其他页面视图
@app.route('/health-data')
def health_data():
    if 'logged_in' in session:
        return render_template('1_health-data.html')
    else:
        return redirect(url_for('login'))

@app.route('/data-analysis')
def data_analysis():
    if 'logged_in' in session:
        return render_template('2_data-analysis.html')
    else:
        return redirect(url_for('login'))

@app.route('/health-advice')
def health_advice():
    if 'logged_in' in session:
        return render_template('3_health-advice.html')
    else:
        return redirect(url_for('login'))

@app.route('/community-interaction')
def community_interaction():
    if 'logged_in' in session:
        return render_template('4_community-interaction.html')
    else:
        return redirect(url_for('login'))

@app.route('/health-resources')
def health_resources():
    if 'logged_in' in session:
        return render_template('5_health-resources.html')
    else:
        return redirect(url_for('login'))

@app.route('/health-data/report')
def health_report():
    if 'logged_in' in session:
        report = HealthReport.query.order_by(HealthReport.id.desc()).first()
        return render_template('1_1_health-report.html', report=report)
    else:
        return redirect(url_for('login'))

@app.route('/health-data/medical-history')
def medical_history():
    if 'logged_in' in session:
        medical_history = MedicalHistory.query.order_by(MedicalHistory.id.desc()).first()
        return render_template('1_2_medical-history.html', medical_history=medical_history)
    else:
        return redirect(url_for('login'))

@app.route('/health-data/health-monitoring')
def health_monitoring():
    if 'logged_in' in session:
        health_monitoring_data = HealthMonitoring.query.order_by(HealthMonitoring.id.desc()).all()
        return render_template('1_3_health-monitoring.html', health_monitoring_data=health_monitoring_data)
    else:
        return redirect(url_for('login'))

# 搜索功能
@app.route('/search', methods=['GET'])
def search():
    query = request.args.get('query')
    return render_template('search_results.html', query=query)


@app.route('/health-data/report_submit', methods=['GET', 'POST'])
def health_report_submit():
    if 'logged_in' in session:
        if request.method == 'POST':
            # 获取表单数据
            name = request.form.get('name')
            blood_pressure = request.form.get('blood_pressure')
            blood_sugar = request.form.get('blood_sugar')
            lipid = request.form.get('lipid')
            ecg = request.form.get('ecg')
            conclusion = request.form.get('conclusion')

            # 打印数据以检查
            print(f"Received data: {name}, {blood_pressure}, {blood_sugar}, {lipid}, {ecg}, {conclusion}")

            try:
                # 将数据存储到数据库
                new_report = HealthReport(
                    name=name,
                    blood_pressure=blood_pressure,
                    blood_sugar=blood_sugar,
                    lipid=lipid,
                    ecg=ecg,
                    conclusion=conclusion
                )
                db.session.add(new_report)
                db.session.commit()
                print("数据提交成功")
            except Exception as e:
                db.session.rollback()
                print(f"提交失败: {e}")

            return redirect(url_for('health_data'))  # 提交后返回健康数据整合页面

        return render_template('1_1_health-report.html')
    else:
        return redirect(url_for('login'))


@app.route('/health-data/medical-history_submit', methods=['GET', 'POST'])
def medical_history_submit():
    if 'logged_in' in session:
        if request.method == 'POST':
            # 获取表单数据
            past_medical_history = request.form['past_medical_history']
            chronic_diseases = request.form['chronic_diseases']
            current_medications = request.form['current_medications']

            # 将数据存储到数据库
            new_history = MedicalHistory(
                past_medical_history=past_medical_history,
                chronic_diseases=chronic_diseases,
                current_medications=current_medications
            )
            db.session.add(new_history)
            db.session.commit()

            return redirect(url_for('health_data'))  # 提交后返回健康数据整合页面

        return render_template('1_2_medical-history.html')
    else:
        return redirect(url_for('login'))


@app.route('/health-data/health-monitoring_submit', methods=['GET', 'POST'])
def health_monitoring_submit():
    if 'logged_in' in session:
        if request.method == 'POST':
            # 获取表单数据
            date = request.form['date']
            weight = request.form['weight']
            blood_pressure = request.form['blood_pressure']
            blood_sugar = request.form['blood_sugar']
            steps = request.form['steps']
            sleep_duration = request.form['sleep_duration']

            # 将数据存储到数据库
            new_monitoring = HealthMonitoring(
                date=date,
                weight=weight,
                blood_pressure=blood_pressure,
                blood_sugar=blood_sugar,
                steps=steps,
                sleep_duration=sleep_duration
            )
            db.session.add(new_monitoring)
            db.session.commit()

            return redirect(url_for('health_data'))  # 提交后返回健康数据整合页面

        return render_template('1_3_health-monitoring.html')
    else:
        return redirect(url_for('login'))


# 创建数据库表
with app.app_context():
    db.create_all()

# 创建默认用户
create_default_user()

@app.route('/')
def index():
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
